<?php
if(!function_exists( 'edo_themne_color' )){
	function edo_themne_color(){
		$main_color = edo_option( 'kt_theme_color', '#5a88ca' );
		$css = <<<CSS
	/* Color Scheme */

	body a:hover,
	body .top-bar .top-bar-link.dot>li>a:before,
	body .block-category .categories>li>a:before{
		color: {$main_color};
	}

	body #category-select-menu .ui-state-focus,
	body .main-bg,
	body .block-wrap-cart .iner-block-cart>a:after,
	body .main-menu .navbar-nav>li>a:hover, 
	body .main-menu .navbar-nav>li.active>a, 
	body .main-menu .navbar-nav>li>a:focus,
	body .main-menu .navbar-nav>li>a:visited,
	body .main-menu .dropdown-menu>li:hover,
	body .button-radius .icon:before,
	body .megamenu .widget_nav_menu ul>li:hover,
	body .block-category .nav-tab>li>a:hover, 
	body .block-category .nav-tab>li.active>a,
	body .block-category .categories>li>a>.text:before,
	body .block-category .categories>li>a>.text:before,
	body .block-category .categories>li>a:hover>.text,
	body .owl-carousel .owl-next:hover,
	body .owl-carousel .owl-prev:hover,
	body .footer-block-box .block-input-box .block-button, 
	body .footer-block-box .block-input-box .mailchimp-submit,
	body .block-social .list-social li>a:hover,
	body .scroll_top,
	body .block-header-right .item.item-cart,
	body .block-vertical-menu .vertical-head,
	body .block-tabs .nav-tab li a:hover, 
	body .block-tabs .nav-tab li.active a,
	body .block-hot-deals2 .nav-tab li.active a:before, 
	body .block-hot-deals2 .nav-tab li:hover a:before{
		background-color: {$main_color};
	}

	body .block-category .nav-tab>li>a:hover, 
	body .block-category .nav-tab>li.active>a,
	body .owl-carousel .owl-next:hover,
	body .owl-carousel .owl-prev:hover,
	body .block-social .list-social li>a:hover,
	body .block-header-right .item .icon{
		border-color: {$main_color};
	}
	body .block-category .categories>li>a>.text:after{
		 border-left: 16px solid {$main_color};
	}
CSS;
		?>
		<style id="edo-theme-color" type="text/css">
	        <?php echo $css;?>
	    </style>
		<?php
	}
}

add_action( 'wp_enqueue_scripts', 'edo_themne_color' );
