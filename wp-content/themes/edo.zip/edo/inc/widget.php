<?php
require THEME_DIR . '/inc/widgets/edo_image.php';
require THEME_DIR . '/inc/widgets/product-special-sidebar.php';
require THEME_DIR . '/inc/widgets/top-sellers.php';