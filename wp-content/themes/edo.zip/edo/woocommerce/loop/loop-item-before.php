<?php
/**
 * Product Loop Item Before
 *
 * @author 		AngelsIT
 * @package 	Edo/Woocommerce
 * @version     1.0
 */
?>
<li class="product">