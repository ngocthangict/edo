<?php
/**
 * Product Loop Item After
 *
 * @author 		AngelsIT
 * @package 	Edo/Woocommerce
 * @version     1.0
 */
?>
</li>